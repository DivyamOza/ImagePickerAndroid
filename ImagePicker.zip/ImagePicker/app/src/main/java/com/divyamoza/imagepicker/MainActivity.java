package com.divyamoza.imagepicker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.dhaval2404.imagepicker.ImagePicker;

public class MainActivity extends AppCompatActivity {
    public Button btnGallery, btnCamera,btnDialog;
    public ImageView imgView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                captureImageUsingCamera();
            }
        });

        btnGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickImageFromGallery();
            }
        });

        btnDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialogForImagePicker();
            }
        });
    }

    /**
     * This method is use to ImagePicker with Dialog of Camera & Gallery
     */
    private void showDialogForImagePicker() {
        ImagePicker.Companion.with(this)
                .crop()	    			//Crop image(Optional), Check Customization for more option
                .compress(1024)			//Final image size will be less than 1 MB(Optional)
                .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                .start();
    }

    /**
     * This method is use to ImagePicker with using Gallery only
     */
    public void pickImageFromGallery() {
        ImagePicker.Companion.with(this)
                .galleryOnly()
                .cropSquare()
                //crop()
                .start();
    }

    /**
     * This method is used to show the Image which is selected/clicked
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            imgView.setImageURI(data.getData());
        }
    }

    /**
     * This method is use to captureImage & Set to ImageView
     */
    public void captureImageUsingCamera() {
        ImagePicker.Companion.with(this)
                .cameraOnly()    //User can only capture image using Camera
                .cropSquare()
                //.crop()
                .start();


    }

    /**
     * This method is use to initialize all view
     */
    public void init() {
        btnCamera = findViewById(R.id.btnCamera);
        btnGallery = findViewById(R.id.btnGallery);
        imgView = findViewById(R.id.imageView);
        btnDialog = findViewById(R.id.btnDialog);
    }
}